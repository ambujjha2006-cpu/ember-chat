require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const Database = require('better-sqlite3');
const { nanoid } = require('nanoid');

const app = express();
const PORT = process.env.PORT || 3000;
const GROQ_API_KEY = process.env.GROQ_API_KEY;
const GROQ_MODEL = process.env.GROQ_MODEL || 'llama-3.3-70b-versatile';

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ---------- Database setup ----------
const db = new Database(path.join(__dirname, 'chat.db'));
db.pragma('journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL DEFAULT 'New chat',
    created_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('user','assistant')),
    content TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
  );
`);

const stmts = {
  createSession: db.prepare('INSERT INTO sessions (id, title, created_at) VALUES (?, ?, ?)'),
  listSessions: db.prepare('SELECT id, title, created_at FROM sessions ORDER BY created_at DESC'),
  getSession: db.prepare('SELECT id, title, created_at FROM sessions WHERE id = ?'),
  renameSession: db.prepare('UPDATE sessions SET title = ? WHERE id = ?'),
  deleteSession: db.prepare('DELETE FROM sessions WHERE id = ?'),
  deleteMessagesFor: db.prepare('DELETE FROM messages WHERE session_id = ?'),
  insertMessage: db.prepare(
    'INSERT INTO messages (session_id, role, content, created_at) VALUES (?, ?, ?, ?)'
  ),
  getMessages: db.prepare(
    'SELECT id, role, content, created_at FROM messages WHERE session_id = ? ORDER BY id ASC'
  ),
};

// ---------- Helpers ----------
function makeTitleFromMessage(text) {
  const clean = text.trim().replace(/\s+/g, ' ');
  return clean.length > 40 ? clean.slice(0, 40) + '…' : clean || 'New chat';
}

async function callGroq(history) {
  if (!GROQ_API_KEY) {
    throw new Error(
      'No GROQ_API_KEY set on the server. Add one to your .env file (see .env.example).'
    );
  }

  const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${GROQ_API_KEY}`,
    },
    body: JSON.stringify({
      model: GROQ_MODEL,
      messages: [
        {
          role: 'system',
          content:
            'You are Ember, a helpful, friendly, and concise AI assistant. Answer clearly and use markdown formatting (like lists or code blocks) when it helps readability.',
        },
        ...history,
      ],
      temperature: 0.7,
      max_tokens: 1024,
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Groq API error (${response.status}): ${errText}`);
  }

  const data = await response.json();
  return data.choices?.[0]?.message?.content?.trim() || '(no response)';
}

// ---------- Routes ----------

// List all chat sessions
app.get('/api/sessions', (req, res) => {
  res.json(stmts.listSessions.all());
});

// Create a new chat session
app.post('/api/sessions', (req, res) => {
  const id = nanoid(10);
  const created_at = Date.now();
  stmts.createSession.run(id, 'New chat', created_at);
  res.json({ id, title: 'New chat', created_at });
});

// Get messages for a session
app.get('/api/sessions/:id/messages', (req, res) => {
  const session = stmts.getSession.get(req.params.id);
  if (!session) return res.status(404).json({ error: 'Session not found' });
  res.json(stmts.getMessages.all(req.params.id));
});

// Rename a session
app.patch('/api/sessions/:id', (req, res) => {
  const { title } = req.body;
  const session = stmts.getSession.get(req.params.id);
  if (!session) return res.status(404).json({ error: 'Session not found' });
  stmts.renameSession.run(title || 'New chat', req.params.id);
  res.json({ ok: true });
});

// Delete a session
app.delete('/api/sessions/:id', (req, res) => {
  stmts.deleteMessagesFor.run(req.params.id);
  stmts.deleteSession.run(req.params.id);
  res.json({ ok: true });
});

// Send a message, get an AI reply, persist both
app.post('/api/sessions/:id/messages', async (req, res) => {
  const sessionId = req.params.id;
  const { message } = req.body;

  if (!message || !message.trim()) {
    return res.status(400).json({ error: 'Message is required' });
  }

  const session = stmts.getSession.get(sessionId);
  if (!session) return res.status(404).json({ error: 'Session not found' });

  const now = Date.now();
  stmts.insertMessage.run(sessionId, 'user', message, now);

  // Auto-title new chats from the first message
  const priorMessages = stmts.getMessages.all(sessionId);
  if (priorMessages.length === 1) {
    stmts.renameSession.run(makeTitleFromMessage(message), sessionId);
  }

  try {
    const history = priorMessages.map((m) => ({ role: m.role, content: m.content }));
    const reply = await callGroq(history);
    stmts.insertMessage.run(sessionId, 'assistant', reply, Date.now());
    res.json({ reply });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// Health check (useful for hosting platforms)
app.get('/api/health', (req, res) => res.json({ ok: true }));

app.listen(PORT, () => {
  console.log(`Ember chatbot server running on http://localhost:${PORT}`);
  if (!GROQ_API_KEY) {
    console.warn('⚠️  GROQ_API_KEY is not set — chat replies will fail until you add one to .env');
  }
});
